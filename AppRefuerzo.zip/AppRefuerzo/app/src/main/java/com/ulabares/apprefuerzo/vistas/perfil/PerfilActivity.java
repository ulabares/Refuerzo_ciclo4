package com.ulabares.apprefuerzo.vistas.perfil;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.ulabares.apprefuerzo.R;

public class PerfilActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil);
    }
}