package com.ulabares.apprefuerzo.controladores;

public class ConstantesFirebase {

    public static final String USUARIOS="users";
}
